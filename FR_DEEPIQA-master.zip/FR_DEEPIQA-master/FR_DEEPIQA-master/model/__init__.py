import sys
#print(sys.path)
sys.path.append("C:/Users/zbb/Desktop/FR_DEEPIQA-master/FR_DEEPIQA-master/model")