import torch
from torch import nn
from model.model import DeepQANet
import logging


    #print(DeepQANet)
logger=logging.getLogger('IQA')
