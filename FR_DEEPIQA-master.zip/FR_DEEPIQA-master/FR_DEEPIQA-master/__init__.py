import sys
sys.path.insert(0,r'C:\Users\zbb\Desktop\FR_DEEPIQA-master\FR_DEEPIQA-master\deploy_flask')