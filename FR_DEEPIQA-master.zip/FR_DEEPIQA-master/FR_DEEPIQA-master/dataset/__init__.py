import sys
#print(sys.path)
sys.path.insert(0,"C:/Users/zbb/Desktop/FR_DEEPIQA-master/FR_DEEPIQA-master/dataset")